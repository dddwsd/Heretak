package Heretak.heretak;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HeretakApplication {

	public static void main(String[] args) {
		SpringApplication.run(HeretakApplication.class, args);
	}

}
