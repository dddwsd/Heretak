package Heretak.heretak;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeretakApplicationTests {

	@Test
	void contextLoads() {
	}

}
